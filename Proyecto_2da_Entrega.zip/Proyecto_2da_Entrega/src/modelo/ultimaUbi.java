package modelo;


public class ultimaUbi {
    
    private String noVivienda;
    private String localidad;
    private String ciudad;
    private String departamento;
    private String pais;
    
    public ultimaUbi(){
        
    }

    public ultimaUbi(String noVivienda, String localidad, String ciudad, String departamento, String pais) {
        this.noVivienda = noVivienda;
        this.localidad = localidad;
        this.ciudad = ciudad;
        this.departamento = departamento;
        this.pais = pais;
    }

    /**
     * @return the noVivienda
     */
    public String getNoVivienda() {
        return noVivienda;
    }

    /**
     * @param noVivienda the noVivienda to set
     */
    public void setNoVivienda(String noVivienda) {
        this.noVivienda = noVivienda;
    }

    /**
     * @return the localidad
     */
    public String getLocalidad() {
        return localidad;
    }

    /**
     * @param localidad the localidad to set
     */
    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }

    /**
     * @return the ciudad
     */
    public String getCiudad() {
        return ciudad;
    }

    /**
     * @param ciudad the ciudad to set
     */
    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    /**
     * @return the departamento
     */
    public String getDepartamento() {
        return departamento;
    }

    /**
     * @param departamento the departamento to set
     */
    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    /**
     * @return the pais
     */
    public String getPais() {
        return pais;
    }

    /**
     * @param pais the pais to set
     */
    public void setPais(String pais) {
        this.pais = pais;
    }
    
    
    
}

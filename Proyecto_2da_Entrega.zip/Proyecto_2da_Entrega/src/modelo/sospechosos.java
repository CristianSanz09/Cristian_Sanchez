package modelo;


public class sospechosos extends ultimaUbi {
    private int noId;
    private String nombre;
    private String alias;
    private int edad;
    private String foto;
    private String descripFisica;
    
    public sospechosos(){
        
    }

    public sospechosos(int noId, String nombre, String alias, int edad, String descripFisica) {
        this.noId = noId;
        this.nombre = nombre;
        this.alias = alias;
        this.edad = edad;
        this.descripFisica = descripFisica;
    }
    
    public sospechosos(int noId, String nombre, String alias, int edad, String noVivienda, String localidad, String ciudad, String departamento, String pais) {
        super(noVivienda, localidad, ciudad, departamento, pais);
        this.noId = noId;
        this.nombre = nombre;
        this.alias = alias;
        this.edad = edad;
    }

    public int getNoId() {
        return noId;
    }

    /**
     * @param noId the noId to set
     */
    public void setNoId(int noId) {
        this.noId = noId;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the alias
     */
    public String getAlias() {
        return alias;
    }

    /**
     * @param alias the alias to set
     */
    public void setAlias(String alias) {
        this.alias = alias;
    }

    /**
     * @return the edad
     */
    public int getEdad() {
        return edad;
    }

    /**
     * @param edad the edad to set
     */
    public void setEdad(int edad) {
        this.edad = edad;
    }

    /**
     * @return the foto
     */
    public String getFoto() {
        return foto;
    }

    /**
     * @param foto the foto to set
     */
    public void setFoto(String foto) {
        this.foto = foto;
    }

    /**
     * @return the descripFisica
     */
    public String getDescripFisica() {
        return descripFisica;
    }

    /**
     * @param descripFisica the descripFisica to set
     */
    public void setDescripFisica(String descripFisica) {
        this.descripFisica = descripFisica;
    }

    public String mostrarDatos() {
        return "SOSPECHOSOS\n" + "\nIdentificacion: " + noId + "\nNombre: " + nombre + "\nAlias: " + alias + "\nEdad: " + edad + "\nDescripcion Fisica: " + descripFisica;
    }
    
    
}

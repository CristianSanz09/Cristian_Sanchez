package modelo;

public class casos {
    
    private int noCasos;
    private String descripcion;
    private int codigoPrioridad;
    private String nombreClave;
    
    public casos(){
        
    }

    public casos(int noCasos, String descripcion, int codigoPrioridad, String nombreClave) {
        this.noCasos = noCasos;
        this.descripcion = descripcion;
        this.codigoPrioridad = codigoPrioridad;
        this.nombreClave = nombreClave;
    }

    /**
     * @return the noCasos
     */
    public int getNoCasos() {
        return noCasos;
    }

    /**
     * @param noCasos the noCasos to set
     */
    public void setNoCasos(int noCasos) {
        this.noCasos = noCasos;
    }

    /**
     * @return the descripcion
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * @param descripcion the descripcion to set
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * @return the codigoPrioridad
     */
    public int getCodigoPrioridad() {
        return codigoPrioridad;
    }

    /**
     * @param codigoPrioridad the codigoPrioridad to set
     */
    public void setCodigoPrioridad(char codigoPrioridad) {
        this.codigoPrioridad = codigoPrioridad;
    }

    /**
     * @return the nombreClave
     */
    public String getNombreClave() {
        return nombreClave;
    }

    /**
     * @param nombreClave the nombreClave to set
     */
    public void setNombreClave(String nombreClave) {
        this.nombreClave = nombreClave;
    }
    
}

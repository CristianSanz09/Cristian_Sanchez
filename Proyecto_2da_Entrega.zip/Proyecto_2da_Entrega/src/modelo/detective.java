package modelo;

public class detective {
    
    private int noId;
    private String nombre;
    private String apellido;
    private int añosExp;
    private String especializacion;
    
    public detective(){
        
    }

    public detective(int noId, String nombre, String apellido, int añosExp, String especializacion) {
        this.noId = noId;
        this.nombre = nombre;
        this.apellido = apellido;
        this.añosExp = añosExp;
        this.especializacion = especializacion;
    }

    /**
     * @return the noId
     */
    public int getNoId() {
        return noId;
    }

    /**
     * @param noId the noId to set
     */
    public void setNoId(int noId) {
        this.noId = noId;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the apellido
     */
    public String getApellido() {
        return apellido;
    }

    /**
     * @param apellido the apellido to set
     */
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    /**
     * @return the añosExp
     */
    public int getAñosExp() {
        return añosExp;
    }

    /**
     * @param añosExp the añosExp to set
     */
    public void setAñosExp(int añosExp) {
        this.añosExp = añosExp;
    }

    /**
     * @return the especializacion
     */
    public String getEspecializacion() {
        return especializacion;
    }

    /**
     * @param especializacion the especializacion to set
     */
    public void setEspecializacion(String especializacion) {
        this.especializacion = especializacion;
    }

    public String mostrarDatos() {
        return "DETECTIVE\n" + "\nIdentificación: " + noId + "\nNombre: " + nombre + "\nApellido: " + apellido + "\nAños de Experiencia: " + añosExp + "\nEspecialización: " + especializacion;
    }


}

package modelo;


public class bitacora {
    
    private String fechaRegistro;
    private String anotaciones;
    private String bitacoraHistorialAnotaciones;
    
    public bitacora(){
        
    }

    public bitacora(String fechaRegistro, String anotaciones) {
        this.fechaRegistro = fechaRegistro;
        this.anotaciones = anotaciones;
    }

    /**
     * @return the fechaRegistro
     */
    public String getFechaRegistro() {
        return fechaRegistro;
    }

    /**
     * @param fechaRegistro the fechaRegistro to set
     */
    public void setFechaRegistro(String fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    /**
     * @return the anotaciones
     */
    public String getAnotaciones() {
        return anotaciones;
    }

    /**
     * @param anotaciones the anotaciones to set
     */
    public void setAnotaciones(String anotaciones) {
        this.anotaciones = anotaciones;
    }
    
    
    
}

package vista;
import modelo.*;

public class Principal {
    
    public static void main(String[] args) {       
        
        detective DS[] = new detective[3];
        sospechosos SS[] = new sospechosos[3];
        
        DS[0] = new detective(123456789,"Cristian","Sanchez",15, "Homicidio");
        DS[1] = new detective(484963822,"Eider","Estrada",18, "Crimenes Ciberneticos");
        DS[2] = new detective(987412952,"Jairo","Leon",23, "Narcotico");
        
        for (detective detective: DS) {
            System.out.println(detective.mostrarDatos());
            System.out.println("---------------------------------");
        }
        SS[0] = new sospechosos(741252685,"Cristiano Ronaldo","El bicho",26,"Su cara es redonda, estatura alta, contextura endomorfo, pelo un poco rizado, boca es fina, frente amplia, ojos marrones claro.");
        SS[1] = new sospechosos(587426952,"Leonel Messi","La pulga",40,"Su cara es fileña, estatura baja, contextura mesomorfo, cabello marron y liso, ojos marrones oscuros.");
        SS[2] = new sospechosos(369152748,"Teofilo Gutierrez","El perfume",37,"Su cara es semi cuadrada, estatura mesomorfo, contextura mesomorfo, cabello negro y liso, ojos negros.");
        
        for(sospechosos sospechosos: SS){
            System.out.println(sospechosos.mostrarDatos());
            System.out.println("---------------------------------");
        }
    }
}